package gr.uom.java.metric.probability.browser;

import gr.uom.java.metric.probability.test1;

public class test2 extends test1{

	public test2() {
		super();
	}
	
	@Override
	public int bbb() {
		a2++;
		// TODO Auto-generated method stub
		return 0;
	}

}
