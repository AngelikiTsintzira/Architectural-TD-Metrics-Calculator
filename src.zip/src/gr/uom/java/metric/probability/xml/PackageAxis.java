package gr.uom.java.metric.probability.xml;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class PackageAxis
{
	//private String description;
	private String from;
	private String to;
	private Double probability;
	private List<Axis> axisList;
	private Set<String> methods;
	
	//TODO Na pros9esw tin from Package.
	public PackageAxis(String from, String to)
	{
		if(from.isEmpty())
			this.from = "default";
		else
			this.from = from;
		this.from = from;
		this.to = to;
		axisList = new ArrayList<Axis>();
		methods = new HashSet<String>();
	}
	
	public PackageAxis(){}
	
	/*public String getDescription() {
		return description;
	}*/

	public ListIterator getAxisListIterator()
	{
		return this.axisList.listIterator();
	}
	
	public void addAxis(Axis axis)
	{
		axisList.add(axis);
	}
	
	public String getToPackage() {
		return to;
	}
	
	public void setToPackage(String to)
	{
		this.to = to;
	}

	public String getFromPackage() {
		return this.from;
	}
	
	public Double getProbability() {
		return probability;
	}
	
	//TASK 3
	/*public void updatePropagation()
	{
		ListIterator ait = axisList.listIterator();
		Set<String> methods = new HashSet<String>();
		double num = 0.0;
		double denum = 0.0;
		
		//Vazw tis me9odous pou kalountai se mia lista
		while(ait.hasNext())
		{
			Axis a = (Axis)ait.next();
			ListIterator<String> mci = a.getMethodsCalledListIterator();
			while(mci.hasNext())
				methods.add(mci.next());
		}
		
		ait = axisList.listIterator();
		//TODO - Last Bug
		while(ait.hasNext())
		{
			Axis a = (Axis)ait.next();
			num += a.getRFC() + a.getNOP() + a.getNPRF_USED();
			denum += a.getNPM()+ a.getNPRF();
		}
		if(denum == 0)
			probability = 0.0;
		else
			probability = num/denum;
		System.out.print("\nTo: " + to + " --- " + probability);
		System.out.print("");
	}*/
	
	public double updatePropagation()
	{
		ListIterator ait = axisList.listIterator();
		double num = 0.0;
		double denum = 0.0;
		double tempNum = 0.0;
		
//		if (from.contains("controller") && to.contains("preferences")) {
//			System.out.println("FROM: " + from + "- TO: " + to);
//		}
		
		Hashtable<String, Double> sourceClasses = new Hashtable<String, Double>();
		while(ait.hasNext()){
			Axis a = (Axis)ait.next();
			ListIterator mit = a.getMethodsCalledListIterator();
			while(mit.hasNext())
				methods.add((String)mit.next());

			if (sourceClasses.containsKey(a.getToClass()) == false) {
				sourceClasses.put(a.getToClass(), a.getNPM() + a.getAttributes());
				num += a.getNOP() + a.getNPRF_USED();
			}
			
			System.out.println("\t\t" + a.getFromClass() + " --> " + a.getToClass() + " " + a.getNPM() + " " + a.getNOP() + " " + a.getNPRF_USED());
		}

		Set<String> scSet = sourceClasses.keySet();
		Iterator scit = scSet.iterator();

		num = num + methods.size();
		
		while(scit.hasNext()) {
			Double temp = sourceClasses.get(scit.next()); 
			denum += temp;
			System.out.println("denum: " + temp);
		}
		
		Iterator<String> s = methods.iterator();
		while(s.hasNext())
			System.out.println("\t\t" + s.next());
		System.out.println("num:" + num);
		System.out.println("");
		
//		if (num == 4 && denum == 1) {
//			System.out.println("FROM: " + from + "- TO: " + to);
//		}
		
		
		if(denum == 0)
			probability = 0.0;
		else
			probability = num/denum;
		
		if (this.probability < 0.001) this.probability = 0.001;
		if (this.probability > 0.999) this.probability = 0.020;
		
		
		return probability;
	}
	
	public double updatePackagePropagation(String classFrom) throws Exception, IOException
	{
		ListIterator ait = axisList.listIterator();
		double num = 0.0;
		double denum = 0.0;
		
		Hashtable<String, Double> sourceClasses = new Hashtable<String, Double>();
		while(ait.hasNext()){
			Axis a = (Axis)ait.next();
			ListIterator mit = a.getMethodsCalledListIterator();
			while(mit.hasNext())
				methods.add((String)mit.next());

			if (sourceClasses.containsKey(a.getToClass()) == false) {
				sourceClasses.put(a.getToClass(), a.getNPM() + a.getAttributes());
				num += a.getNOP() + a.getNPRF_USED();
			}
			
			System.out.println("\t\t" + a.getFromClass() + " --> " + a.getToClass() + " " + a.getNPM() + " " + a.getNOP() + " " + a.getNPRF_USED());
		}

		Set<String> scSet = sourceClasses.keySet();
		Iterator scit = scSet.iterator();
		num = num + methods.size();
		while(scit.hasNext()) {
			Double temp = sourceClasses.get(scit.next()); 
			denum += temp;
			System.out.println("denum: " + temp);
		}
		
		Iterator<String> s = methods.iterator();
		while(s.hasNext())
			System.out.println("\t\t" + s.next());
		System.out.println("num:" + num);
		System.out.println("");
		
		if(denum == 0)
			probability = 0.0;
		else
			probability = num/denum;
		
		if (this.probability < 0.001) this.probability = 0.001;
		if (this.probability > 0.999) this.probability = 0.020;
		
		if (this.probability > 0) {
			boolean found = false;
			String lineToWrite = classFrom + ";" + this.to+ ";" + this.probability; 
			File fileName = new File("packageCouplingOutput.csv");
			PrintWriter writer = new PrintWriter(new FileOutputStream(fileName, true));
			Scanner scanner = new Scanner(fileName);
		    while (scanner.hasNextLine()) 
		    {
		        String lineFromFile = scanner.nextLine();
		        if (lineToWrite.equals(lineFromFile))
		        {
		           found = true;
		           break;
		        }
		    }
		    if (!found) {
		    	writer.println(lineToWrite);
		    }
			writer.close();
		    scanner.close();
		}
		return probability;
	}
	
	public void createPackageCohesionFile() throws Exception, IOException
	{
		File fileName = new File("packageCohesionOutput.csv");
		List<String> packageNameList = new ArrayList<String>();
		Map<String, Set<String>> packageClassNameMap = new HashMap<String, Set<String>>();
		Map<String, Set<String>> packageCalledClassNameMap = new HashMap<String, Set<String>>();
		Scanner scanner = new Scanner(fileName);
	    while (scanner.hasNextLine()) 
	    {
	    	String[] splitLine = scanner.nextLine().split(";");
	        
	        packageNameList.add(splitLine[0]);
	        Set<String> classNames  = new HashSet<String>();
	        if(packageClassNameMap.containsKey(splitLine[0])) {
	        	classNames = packageClassNameMap.get(splitLine[0]);
	        }
        	classNames.add(splitLine[1]);
        	packageClassNameMap.put(splitLine[0], classNames);
	        
        	classNames  = new HashSet<String>();
	        if(!splitLine[2].equals("null")) {
	        	if(packageCalledClassNameMap.containsKey(splitLine[0])) {
		        	classNames = packageCalledClassNameMap.get(splitLine[0]);
		        }
	        	classNames.add(splitLine[2]);
	        	packageCalledClassNameMap.put(splitLine[0], classNames);
	        }
	    }
	    scanner.close();
	    Set<String> packageNameSet = new HashSet<String>(packageNameList);
	    
	    File fileName1 = new File("packageCohesionOutputFinal.csv");
	    PrintWriter writerPackages = new PrintWriter(new FileOutputStream(fileName1, true));
	    for (String s : packageNameSet) {
	    	double packageCalledClassNameMapValue = 0;
	    	if(packageCalledClassNameMap.get(s)!=null) {
	    		packageCalledClassNameMapValue = (double)packageCalledClassNameMap.get(s).size();
	    	}
	    	double cohesion = packageCalledClassNameMapValue/((double)packageClassNameMap.get(s).size());
	    	writerPackages.println(s + "; " + packageCalledClassNameMapValue + "/" + packageClassNameMap.get(s).size() + "; " + cohesion);
	    }
	    writerPackages.close();
	}

	public void createPackageCouplingFile() throws Exception, IOException
	{
		File fileName = new File("packageCouplingOutput.csv");
		Map<String, List<Double>> packageClassNameMap = new HashMap<String, List<Double>>();
		Scanner scanner = new Scanner(fileName);
	    while (scanner.hasNextLine()) 
	    {
	    	String[] splitLine = scanner.nextLine().split(";");
	    	List<Double> td  = new ArrayList<Double>();
	    	if(packageClassNameMap.containsKey(splitLine[0])) {
	        	td = packageClassNameMap.get(splitLine[0]);
	        }
	        td.add(Double.parseDouble(splitLine[2]));
        	packageClassNameMap.put(splitLine[0], td);
	    }
	    scanner.close();
	    
	    File fileName1 = new File("packageCouplingOutputFinal.csv");
	    PrintWriter writerPackages = new PrintWriter(new FileOutputStream(fileName1, true));
	    for (Map.Entry<String, List<Double>> entry : packageClassNameMap.entrySet())
		{
	    	String packageNameSet = entry.getKey();
	    	List<Double> td  = new ArrayList<Double>();
	        td = packageClassNameMap.get(packageNameSet);
	        double valueSum = 0;
	        for (double s : td) {
	        	valueSum += s;
	        }
			//TDavg
    		double valueAvg = valueSum / td.size(); 
	    	writerPackages.println(packageNameSet + "; " + valueSum + "; " + valueAvg);
		}
	    writerPackages.close();
	}
	
	public void createTDCouplingCohesionFile() throws Exception, IOException
	{
		//create final file and add technical depth data
		File packageTDCouplingCohesion = new File("packageTDCouplingCohesion.xlsx");
		if (!packageTDCouplingCohesion.exists()){
			createFinalXLSXFile();
		}
		
		//get coupling data
		File couplingFinal = new File("packageCouplingOutputFinal.csv");
		Map<String, String[]> packageCouplingMap = new HashMap<String, String[]>();
		Scanner scanner = new Scanner(couplingFinal);
	    while (scanner.hasNextLine()) 
	    {
	    	String[] splitLine = scanner.nextLine().split(";");
	    	String[] couplingValues = {splitLine[1], splitLine[2]};
	    	packageCouplingMap.put(splitLine[0], couplingValues);
	    }
	    scanner.close();
	    
	    //get cohesion data
	    File cohesionFinal = new File("packageCohesionOutputFinal.csv");
		Map<String, String> packageCohesionMap = new HashMap<String, String>();
		scanner = new Scanner(cohesionFinal);
	    while (scanner.hasNextLine()) 
	    {
	    	String[] splitLine = scanner.nextLine().split(";");
	    	packageCohesionMap.put(splitLine[0], splitLine[2]);
	    }
	    scanner.close();
		
	    //set coupling and cohesion in final xlsx
	    FileInputStream fis = new FileInputStream(packageTDCouplingCohesion);
		Workbook wbRead = WorkbookFactory.create(fis);
		Sheet sheetRead = wbRead.getSheetAt(0);
		XSSFRow rowRead; 
		XSSFCell cell;
		Iterator rows = sheetRead.rowIterator();
		while (rows.hasNext())
		{
			rowRead=(XSSFRow) rows.next();
			cell = rowRead.getCell(0);
			String packageName = cell.getStringCellValue();
			if(!packageName.equals("packageName")) {
				for (Map.Entry<String, String[]> entry : packageCouplingMap.entrySet())
				{
					if(entry.getKey().endsWith(packageName)) {
						String[] couplingArray  = packageCouplingMap.get(entry.getKey());
						XSSFCell newCell = rowRead.createCell(3);
						newCell.setCellValue(couplingArray[0]);
						newCell = rowRead.createCell(4);
						newCell.setCellValue(couplingArray[1]);
					}
				}
				for (Map.Entry<String, String> entry : packageCohesionMap.entrySet())
				{
					if(entry.getKey().endsWith(packageName)) {
						String cohesion  = packageCohesionMap.get(entry.getKey());
						XSSFCell newCell = rowRead.createCell(5);
						newCell.setCellValue(cohesion);
					}
				}
			}
		}
		fis.close();
		FileOutputStream fos = new FileOutputStream(packageTDCouplingCohesion);
		wbRead.write(fos);
		wbRead.close();
		fos.flush();
		fos.close();
	}
	
	public void createFinalXLSXFile() throws IOException, EncryptedDocumentException, InvalidFormatException
	{
		//read
		Workbook wbRead = WorkbookFactory.create(new File("TD-Analyzed.xlsx"));
		Sheet sheetRead = wbRead.getSheetAt(0);
		XSSFRow rowRead; 
		XSSFCell cell;
		Iterator rows = sheetRead.rowIterator();
		
		//read initial xlsx file and group data
		Map<String, List<Double>> packageClassNameMap = new HashMap<String, List<Double>>();
		while (rows.hasNext())
		{
			rowRead=(XSSFRow) rows.next();
			cell = rowRead.getCell(1);
			String cellToKeep = cell.getStringCellValue();
			//only keep classes that are in a package
			if(!cellToKeep.equals("full_path") && cellToKeep.contains("/")) {
				try {
					cellToKeep = cellToKeep.substring(0, cellToKeep.lastIndexOf("/")).replaceAll("/", ".");
				}
				catch(Exception e)
				{
					String str = e.getMessage();
					str += str;
				}
				List<Double> td  = new ArrayList<Double>();
		        if(packageClassNameMap.containsKey(cellToKeep)) {
		        	td = packageClassNameMap.get(cellToKeep);
		        }
		        td.add(rowRead.getCell(2).getNumericCellValue());
	        	packageClassNameMap.put(cellToKeep, td);
			}
		}
		wbRead.close();
		
		//write grouped data in tmp file
		File excelFileName = new File("packageTDCouplingCohesion.xlsx");
		String sheetName = "Sheet1";//name of sheet
		XSSFWorkbook wbWrite = new XSSFWorkbook();
		XSSFSheet sheetWrite = wbWrite.createSheet(sheetName) ;
		//iterating r number of rows
		int i=0;
		XSSFRow rowWrite = sheetWrite.createRow(i++);
		XSSFCell cellPath = rowWrite.createCell(0);
		cellPath.setCellValue("packageName");
		XSSFCell cellTDSum = rowWrite.createCell(1);
		cellTDSum.setCellValue("SUM_TD");
		XSSFCell cellTDAvg = rowWrite.createCell(2);
		cellTDAvg.setCellValue("AVG_TD");
		XSSFCell cellCouplingSum = rowWrite.createCell(3);
		cellCouplingSum.setCellValue("SUM_Coupling");
		XSSFCell cellCouplingAvg = rowWrite.createCell(4);
		cellCouplingAvg.setCellValue("AVG_Coupling");
		XSSFCell cellCohesion = rowWrite.createCell(5);
		cellCohesion.setCellValue("Cohesion");
		for (Map.Entry<String, List<Double>> entry : packageClassNameMap.entrySet())
		{
			rowWrite = sheetWrite.createRow(i++);
			//path
			cellPath = rowWrite.createCell(0);
			cellPath.setCellValue(entry.getKey());
			//TDsum
			cellTDSum = rowWrite.createCell(1);
			List<Double> td  = new ArrayList<Double>();
	        td = packageClassNameMap.get(entry.getKey());
	        double valueSum = 0;
	        for (double s : td) {
	        	valueSum += s;
	        }
			cellTDSum.setCellValue(valueSum);
			//TDavg
    		double valueAvg = valueSum / td.size(); 
			cellTDAvg = rowWrite.createCell(2);
			cellTDAvg.setCellValue(valueAvg);
		}
		FileOutputStream fileOut = new FileOutputStream(excelFileName);
		//write this workbook to an Outputstream.
		wbWrite.write(fileOut);
		wbWrite.close();
		fileOut.flush();
		fileOut.close();
	}
	
	public double updatePackagePropagationCohesion(String classFrom) throws Exception, IOException
	{
		ListIterator ait = axisList.listIterator();
		double num = 0.0;
		double denum = 0.0;
		double tempNum = 0.0;
		
//		if (from.contains("controller") && to.contains("preferences")) {
//			System.out.println("FROM: " + from + "- TO: " + to);
//		}
		
		Hashtable<String, Double> sourceClasses = new Hashtable<String, Double>();
		while(ait.hasNext()){
			Axis a = (Axis)ait.next();
			ListIterator mit = a.getMethodsCalledListIterator();
			while(mit.hasNext())
				methods.add((String)mit.next());

			if (sourceClasses.containsKey(a.getToClass()) == false) {
				sourceClasses.put(a.getToClass(), a.getNPM() + a.getAttributes());
				num += a.getNOP() + a.getNPRF_USED();
			}
			
			System.out.println("\t\t" + a.getFromClass() + " --> " + a.getToClass() + " " + a.getNPM() + " " + a.getNOP() + " " + a.getNPRF_USED());
		}

		Set<String> scSet = sourceClasses.keySet();
		Iterator scit = scSet.iterator();

		num = num + methods.size();
		
		while(scit.hasNext()) {
			Double temp = sourceClasses.get(scit.next()); 
			denum += temp;
			System.out.println("denum: " + temp);
		}
		
		Iterator<String> s = methods.iterator();
		while(s.hasNext())
			System.out.println("\t\t" + s.next());
		System.out.println("num:" + num);
		System.out.println("");
		
//		if (num == 4 && denum == 1) {
//			System.out.println("FROM: " + from + "- TO: " + to);
//		}
		
		
		if(denum == 0)
			probability = 0.0;
		else
			probability = num/denum;
		
		if (this.probability < 0.001) this.probability = 0.001;
		if (this.probability > 0.999) this.probability = 0.020;
		
		if (this.probability > 0) {
			boolean found = false;
			String lineToWrite = classFrom + ";" + this.to+ ";" + this.probability; 
			File fileName = new File("packageCohesionOutput.csv");
			PrintWriter writer = new PrintWriter(new FileOutputStream(fileName, true));
			Scanner scanner = new Scanner(fileName);
		    while (scanner.hasNextLine()) 
		    {
		        String lineFromFile = scanner.nextLine();
		        if (lineToWrite.equals(lineFromFile))
		        {
		           found = true;
		           break;
		        }
		    }
		    if (!found) {
		    	writer.println(lineToWrite);
		    }
			writer.close();
		    scanner.close();
		}
	    
		return probability;
	}
}
