package gr.uom.java.metric.probability;

public abstract class test1 {
	
	private int a1=0;
	protected int a2=0;
	protected int a3=0;
	
	public test1() {
		
	}
	
	public void aaa() {
		System.out.println("aaaa");
	}
	
	public abstract int bbb();
}
